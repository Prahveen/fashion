-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2016 at 08:40 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lr`
--
CREATE DATABASE IF NOT EXISTS `lr` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lr`;

-- --------------------------------------------------------

--
-- Table structure for table `baby_and_kids`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `baby_and_kids` (
`id` int(11) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `image_path` varchar(1000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `baby_and_kids`
--

INSERT INTO `baby_and_kids` (`id`, `sub_name`, `value`, `image_path`) VALUES
(1, 'Girls ( Newborn to 4T )', 'girls_newborn', ''),
(2, 'Girls (4 to up )', 'girls', ''),
(3, 'Boys ( Newborn to 4T )', 'girls_newborn', ''),
(4, 'Boys (4 to up )', 'boys', '');

-- --------------------------------------------------------

--
-- Stand-in structure for view `cartdetailes`
--
CREATE TABLE IF NOT EXISTS `cartdetailes` (
`user_id` int(11)
,`username` varchar(32)
,`firstname` varchar(32)
,`secondname` varchar(32)
,`item_id` int(11)
,`item_cat` varchar(50)
,`item_title` varchar(500)
,`price` float
,`phone` int(10)
,`item_quantity` int(11)
,`item_description` varchar(500)
,`image_path` varchar(1000)
);
-- --------------------------------------------------------

--
-- Table structure for table `clothes`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `clothes` (
`id` int(11) NOT NULL,
  `sub_name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `women` varchar(11) DEFAULT 'n',
  `men` varchar(11) DEFAULT 'n',
  `image_path` varchar(1000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clothes`
--

INSERT INTO `clothes` (`id`, `sub_name`, `value`, `women`, `men`, `image_path`) VALUES
(1, 'Dresses', 'dress', 'y', '0', ''),
(2, 'Top & Blouses', 't_b', 'y', '0', ''),
(3, 'Sweaters', 'sweaters', 'y', 'y', ''),
(4, 'T-Shirts', 't-shirts', 'y', 'y', ''),
(5, 'Coats & Jackets', 'c_jackets', 'y', 'y', ''),
(6, 'Jeans', 'jeans', 'y', 'y', ''),
(7, 'Pants', 'pants', 'y', 'y', ''),
(8, 'Shorts', 'shorts', 'y', 'y', ''),
(9, 'Intimate & Sleep', 'init_sleep', 'y', 'n', ''),
(10, 'Skirts', '', 'y', 'n', ''),
(11, 'Casual Shirts', 'casual_shirts', 'n', 'y', ''),
(12, 'Dress Shirsts', 'dress_shirts', 'n', 'y', '');

-- --------------------------------------------------------

--
-- Table structure for table `cover`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `cover` (
`cover_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cover_name` varchar(255) NOT NULL,
  `cover_main` varchar(500) NOT NULL,
  `cover_thumbnail` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cover`
--

INSERT INTO `cover` (`cover_id`, `user_id`, `cover_name`, `cover_main`, `cover_thumbnail`) VALUES
(15, 67, ' life-quote.jpg ', '/cover/life-quote.jpg ', '/cover/thumb/life-quote.jpg.thumb.jpg'),
(18, 75, ' 1622190_874209716025020_1154574902089027516_n.jpg ', '/cover/1622190_874209716025020_1154574902089027516_n.jpg ', '/cover/thumb/1622190_874209716025020_1154574902089027516_n.jpg.thumb.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `creatcart`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `creatcart` (
`item_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_cat` varchar(50) NOT NULL,
  `item_title` varchar(500) NOT NULL,
  `price` float NOT NULL,
  `phone` int(10) NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `item_description` varchar(500) NOT NULL,
  `image_path` varchar(1000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `creatcart`
--

INSERT INTO `creatcart` (`item_id`, `user_id`, `item_cat`, `item_title`, `price`, `phone`, `item_quantity`, `item_description`, `image_path`) VALUES
(12, 75, 'women', 'Frock', 1200, 774547140, 5, 'buy 1 get 1 free', 'view/upload/-6206be0a5bf1cdcf07821bb35090505c-thiru@gmail.com/image_galery/10850305_1651884031737171_9210115248252684606_n.jpg'),
(14, 67, 'women', 'Item', 2400, 774547140, 12, 'awera', 'view/upload/-adf825e70a5bd444872f83e35086a851-prsanna@gmail.com/image_galery/12239872_1651884055070502_7380172764916483590_n.jpg'),
(16, 67, 'men', 'Short', 800, 77454714, 12, '', 'view/upload/-adf825e70a5bd444872f83e35086a851-prsanna@gmail.com/image_galery/11201849_10153693760208514_865843786697660916_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `facebook`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `facebook` (
  `fb_id` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `last_upate_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time_zone` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'login time ',
  `host_add` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facebook`
--

INSERT INTO `facebook` (`fb_id`, `username`, `last_upate_time`, `update_time_zone`, `host_add`) VALUES
('1091168310923457', 'Pra Hv Een', '2016-04-03 00:09:07', '2016-04-02 18:39:14', '::1'),
('1160494827311609', 'Adrian Prahveen', '2016-04-03 00:09:07', '2016-04-02 18:39:14', '::1');

-- --------------------------------------------------------

--
-- Stand-in structure for view `fullprofileuser`
--
CREATE TABLE IF NOT EXISTS `fullprofileuser` (
`user_id` int(11)
,`username` varchar(32)
,`password` varchar(64)
,`firstname` varchar(32)
,`secondname` varchar(32)
,`email` varchar(1024)
,`phone_no` int(13)
,`category` varchar(50)
,`gender` varchar(4)
,`dob` date
,`email_code` varchar(32)
,`active` int(11)
,`password_recover` int(11)
,`type` varchar(8)
,`allow_email` int(11)
,`profile` varchar(55)
,`memory_location` varchar(255)
,`profile_id` int(11)
,`profile_name` varchar(255)
,`profile_main` varchar(500)
,`profile_thumbnail` varchar(500)
,`cover_id` int(11)
,`cover_name` varchar(255)
,`cover_main` varchar(500)
,`cover_thumbnail` varchar(500)
);
-- --------------------------------------------------------

--
-- Table structure for table `message`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `message` (
`id` int(11) NOT NULL,
  `dashboard_user_id` varchar(255) NOT NULL,
  `dashboard_user_msg` longtext NOT NULL,
  `custom_user_id` varchar(255) NOT NULL,
  `custom_user_msg` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `dashboard_user_id`, `dashboard_user_msg`, `custom_user_id`, `custom_user_msg`) VALUES
(1, '75', '', '1160494827311609', 'fgsdg'),
(2, '67', '', '1160494827311609', 'hey\n'),
(3, '75', '', '1160494827311609', 'ehy');

-- --------------------------------------------------------

--
-- Stand-in structure for view `overallstatus`
--
CREATE TABLE IF NOT EXISTS `overallstatus` (
`status_id` int(11)
,`user_id` varchar(255)
,`status` longtext
,`status_reply_id` int(11)
,`reply_user_id` varchar(255)
,`reply_status` longtext
);
-- --------------------------------------------------------

--
-- Table structure for table `profile`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `profile_name` varchar(255) NOT NULL,
  `profile_main` varchar(500) NOT NULL,
  `profile_thumbnail` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `profile`:
--   `user_id`
--       `users` -> `user_id`
--

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profile_id`, `user_id`, `profile_name`, `profile_main`, `profile_thumbnail`) VALUES
(20, 67, ' 6be53451fbff3ddeb203752a882f83e0.png ', '/profile/6be53451fbff3ddeb203752a882f83e0.png ', '/profile/thumb/6be53451fbff3ddeb203752a882f83e0.png.thumb.jpg'),
(21, 75, ' 12065823_1643018365948337_1171613850154864711_n.jpg ', '/profile/12065823_1643018365948337_1171613850154864711_n.jpg ', '/profile/thumb/12065823_1643018365948337_1171613850154864711_n.jpg.thumb.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reply_status`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `reply_status` (
`status_reply_id` int(11) NOT NULL,
  `reply_user_id` varchar(255) NOT NULL,
  `status_id` int(255) NOT NULL,
  `reply_status` longtext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reply_status`
--

INSERT INTO `reply_status` (`status_reply_id`, `reply_user_id`, `status_id`, `reply_status`) VALUES
(4, '', 29, ''),
(5, '', 29, ''),
(6, '', 29, ''),
(7, '', 32, ''),
(8, '', 32, '');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `status` (
`status_id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `status` longtext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_id`, `user_id`, `status`) VALUES
(29, '75', 'afsadf'),
(30, '75', 'sdfas'),
(31, '75', 'saf'),
(32, '67', 'turst in god\n'),
(33, '67', 'hey');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_paypal`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `transaction_paypal` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `complete` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction_paypal`
--

INSERT INTO `transaction_paypal` (`id`, `user_id`, `payment_id`, `hash`, `complete`) VALUES
(6, 67, 'PAY-89F27208DL9289702K2JDOTQ', '15d3820ec5560e87421ab33c03383b65', 0),
(7, 67, 'PAY-2SH54992W6545811UK2JDO2Y', 'fe8f21dbf259db44990f963bb1f7d62f', 0),
(8, 67, 'PAY-09H69758L1280674RK2JFXPY', '88e875d9bd10cc1e0e39c6d3464c22d1', 0),
(9, 67, 'PAY-46L56549RG1686031K2JFYLY', '8599db49e7a9464acf96fe362342d8f3', 1),
(10, 67, 'PAY-04403405CG575254TK2JF2MA', '11da1354e3b4bfd036c318d895c70925', 0),
(11, 67, 'PAY-24A88266RY6713459K4ABC2Q', 'b8e5c7cf0a0029fcb053fa29d40896de', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Apr 02, 2016 at 03:50 PM
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(64) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `secondname` varchar(32) NOT NULL,
  `email` varchar(1024) NOT NULL,
  `phone_no` int(13) NOT NULL,
  `category` varchar(50) NOT NULL,
  `gender` varchar(4) NOT NULL,
  `dob` date NOT NULL,
  `email_code` varchar(32) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `password_recover` int(11) NOT NULL DEFAULT '0',
  `type` varchar(8) NOT NULL DEFAULT 'none',
  `allow_email` int(11) NOT NULL DEFAULT '1',
  `profile` varchar(55) NOT NULL,
  `memory_location` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `secondname`, `email`, `phone_no`, `category`, `gender`, `dob`, `email_code`, `active`, `password_recover`, `type`, `allow_email`, `profile`, `memory_location`) VALUES
(67, 'tomba', '202cb962ac59075b964b07152d234b70', 'tomba', 'chooty', 'tomba@123', 0, 'shoes', 'M', '0000-00-00', '5adcbf2a528a9be2490b50e0f46ccbe8', 1, 0, 'free', 1, '', 'view/upload/-adf825e70a5bd444872f83e35086a851-prsanna@gmail.com'),
(75, 'thiru', '202cb962ac59075b964b07152d234b70', 'sandanam', 'thiruchelvam', 'thiru@gmail.com', 0, '', 'M', '0000-00-00', '90b98e54debf1a8624f2dd6d0e8efee8', 1, 0, 'free', 1, '', 'view/upload/-6206be0a5bf1cdcf07821bb35090505c-thiru@gmail.com');

-- --------------------------------------------------------

--
-- Structure for view `cartdetailes`
--
DROP TABLE IF EXISTS `cartdetailes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cartdetailes` AS (select `users`.`user_id` AS `user_id`,`users`.`username` AS `username`,`users`.`firstname` AS `firstname`,`users`.`secondname` AS `secondname`,`creatcart`.`item_id` AS `item_id`,`creatcart`.`item_cat` AS `item_cat`,`creatcart`.`item_title` AS `item_title`,`creatcart`.`price` AS `price`,`creatcart`.`phone` AS `phone`,`creatcart`.`item_quantity` AS `item_quantity`,`creatcart`.`item_description` AS `item_description`,`creatcart`.`image_path` AS `image_path` from (`users` join `creatcart` on((`users`.`user_id` = `creatcart`.`user_id`))));

-- --------------------------------------------------------

--
-- Structure for view `fullprofileuser`
--
DROP TABLE IF EXISTS `fullprofileuser`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fullprofileuser` AS (select `users`.`user_id` AS `user_id`,`users`.`username` AS `username`,`users`.`password` AS `password`,`users`.`firstname` AS `firstname`,`users`.`secondname` AS `secondname`,`users`.`email` AS `email`,`users`.`phone_no` AS `phone_no`,`users`.`category` AS `category`,`users`.`gender` AS `gender`,`users`.`dob` AS `dob`,`users`.`email_code` AS `email_code`,`users`.`active` AS `active`,`users`.`password_recover` AS `password_recover`,`users`.`type` AS `type`,`users`.`allow_email` AS `allow_email`,`users`.`profile` AS `profile`,`users`.`memory_location` AS `memory_location`,`profile`.`profile_id` AS `profile_id`,`profile`.`profile_name` AS `profile_name`,`profile`.`profile_main` AS `profile_main`,`profile`.`profile_thumbnail` AS `profile_thumbnail`,`cover`.`cover_id` AS `cover_id`,`cover`.`cover_name` AS `cover_name`,`cover`.`cover_main` AS `cover_main`,`cover`.`cover_thumbnail` AS `cover_thumbnail` from ((`users` left join `profile` on((`users`.`user_id` = `profile`.`user_id`))) left join `cover` on((`users`.`user_id` = `cover`.`user_id`))));

-- --------------------------------------------------------

--
-- Structure for view `overallstatus`
--
DROP TABLE IF EXISTS `overallstatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `overallstatus` AS (select `status`.`status_id` AS `status_id`,`status`.`user_id` AS `user_id`,`status`.`status` AS `status`,`reply_status`.`status_reply_id` AS `status_reply_id`,`reply_status`.`reply_user_id` AS `reply_user_id`,`reply_status`.`reply_status` AS `reply_status` from (`status` left join `reply_status` on((`status`.`status_id` = `reply_status`.`status_id`))));

--
-- Indexes for dumped tables
--

--
-- Indexes for table `baby_and_kids`
--
ALTER TABLE `baby_and_kids`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clothes`
--
ALTER TABLE `clothes`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cover`
--
ALTER TABLE `cover`
 ADD PRIMARY KEY (`cover_id`), ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `creatcart`
--
ALTER TABLE `creatcart`
 ADD PRIMARY KEY (`item_id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `facebook`
--
ALTER TABLE `facebook`
 ADD PRIMARY KEY (`fb_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
 ADD PRIMARY KEY (`profile_id`), ADD UNIQUE KEY `user_id_2` (`user_id`), ADD KEY `user_id` (`user_id`), ADD KEY `user_id_3` (`user_id`);

--
-- Indexes for table `reply_status`
--
ALTER TABLE `reply_status`
 ADD PRIMARY KEY (`status_reply_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
 ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `transaction_paypal`
--
ALTER TABLE `transaction_paypal`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `baby_and_kids`
--
ALTER TABLE `baby_and_kids`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `clothes`
--
ALTER TABLE `clothes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `cover`
--
ALTER TABLE `cover`
MODIFY `cover_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `creatcart`
--
ALTER TABLE `creatcart`
MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `reply_status`
--
ALTER TABLE `reply_status`
MODIFY `status_reply_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `transaction_paypal`
--
ALTER TABLE `transaction_paypal`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=76;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
ADD CONSTRAINT `profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
